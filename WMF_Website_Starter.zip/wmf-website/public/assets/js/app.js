const menuToggle = document.querySelector("#menuToggle");
const mainNav = document.querySelector("#mainNav");
menuToggle?.addEventListener("click", () => {
  const open = mainNav.classList.toggle("open");
  menuToggle.setAttribute("aria-expanded", String(open));
});
mainNav?.querySelectorAll("a").forEach(link => link.addEventListener("click", () => {
  mainNav.classList.remove("open");
  menuToggle?.setAttribute("aria-expanded", "false");
}));

document.querySelector("#year").textContent = new Date().getFullYear();

// Hero carousel: pauses while the visitor interacts with the controls.
const slides = [
  { eyebrow: "YOUR IDEAS. OUR CREATIVE EXPERTISE.", title: "Make your next<br><em>big idea</em> matter.", copy: "Thoughtful creative and publishing support that helps your work reach its full potential." },
  { eyebrow: "FOR AUTHORS AND PUBLISHERS", title: "Give your story<br><em>the attention</em> it deserves.", copy: "Editorial, design, publishing and promotional services shaped around your book." },
  { eyebrow: "FOR BUSINESSES WITH A VISION", title: "Build a brand<br><em>that connects.</em>", copy: "Creative partnership and practical digital support for your next stage of growth." }
];
let currentSlide = 0;
let carouselTimer;
const dots = [...document.querySelectorAll("#heroDots button")];
function showSlide(index) {
  currentSlide = index;
  const slide = slides[index];
  document.querySelector("#heroEyebrow").textContent = slide.eyebrow;
  document.querySelector("#heroTitle").innerHTML = slide.title;
  document.querySelector("#heroCopy").textContent = slide.copy;
  dots.forEach((dot, i) => dot.classList.toggle("active", i === index));
  document.querySelector(".hero-counter").innerHTML = `0${index + 1} <i>/</i> 03`;
}
function startCarousel() {
  clearInterval(carouselTimer);
  carouselTimer = setInterval(() => showSlide((currentSlide + 1) % slides.length), 5000);
}
dots.forEach((dot, i) => dot.addEventListener("click", () => { showSlide(i); startCarousel(); }));
document.querySelector(".hero")?.addEventListener("mouseenter", () => clearInterval(carouselTimer));
document.querySelector(".hero")?.addEventListener("mouseleave", startCarousel);
startCarousel();

// Contact form is intentionally not wired to a live database yet.
// Connect it to a Firebase callable function before production use.
document.querySelector("#contactForm")?.addEventListener("submit", event => {
  event.preventDefault();
  const feedback = document.querySelector("#contactFeedback");
  feedback.textContent = "Thanks for your interest. The enquiry form will be activated when the Firebase project is connected.";
});
