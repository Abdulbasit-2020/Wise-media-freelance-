const { onCall, HttpsError } = require("firebase-functions/v2/https");
const { defineSecret } = require("firebase-functions/params");
const { initializeApp } = require("firebase-admin/app");
const { getFirestore, FieldValue } = require("firebase-admin/firestore");
const { getAuth } = require("firebase-admin/auth");

initializeApp();
const db = getFirestore();
const PAYSTACK_SECRET_KEY = defineSecret("PAYSTACK_SECRET_KEY");

// Admin-only helper. Use this function from a trusted admin interface after
// verifying the operator's identity and approval workflow.
exports.setAdminClaim = onCall(async (request) => {
  if (!request.auth || request.auth.token.admin !== true) {
    throw new HttpsError("permission-denied", "Administrator access required.");
  }
  const { uid, enabled } = request.data || {};
  if (typeof uid !== "string" || typeof enabled !== "boolean") {
    throw new HttpsError("invalid-argument", "A valid uid and enabled flag are required.");
  }
  await getAuth().setCustomUserClaims(uid, { admin: enabled });
  return { success: true };
});

// Payment initialization is server-side. Amount is read from the service record,
// never trusted from the browser. Do not deploy until the service schema and
// currencies are approved by WMF and the secret is configured.
exports.initializePaystackPayment = onCall(
  { secrets: [PAYSTACK_SECRET_KEY], cors: true },
  async (request) => {
    if (!request.auth) throw new HttpsError("unauthenticated", "Please sign in first.");
    const { serviceId, brief, customerName, customerEmail } = request.data || {};
    if (!serviceId || typeof serviceId !== "string" ||
        typeof customerEmail !== "string" || typeof customerName !== "string") {
      throw new HttpsError("invalid-argument", "Missing order information.");
    }

    const serviceRef = db.collection("services").doc(serviceId);
    const serviceSnap = await serviceRef.get();
    if (!serviceSnap.exists || serviceSnap.data().published !== true) {
      throw new HttpsError("not-found", "This service is not currently available.");
    }
    const service = serviceSnap.data();
    if (!Number.isInteger(service.amountMinor) || service.amountMinor <= 0 ||
        !/^[A-Z]{3}$/.test(service.currency || "")) {
      throw new HttpsError("failed-precondition", "This service is not yet configured for online payment.");
    }

    const orderRef = db.collection("orders").doc();
    await orderRef.set({
      customerUid: request.auth.uid,
      serviceId,
      serviceName: service.name,
      brief: String(brief || "").slice(0, 5000),
      customerName: customerName.slice(0, 160),
      customerEmail: customerEmail.slice(0, 254),
      amountMinor: service.amountMinor,
      currency: service.currency,
      status: "Awaiting Payment",
      paymentStatus: "unpaid",
      createdAt: FieldValue.serverTimestamp()
    });

    const response = await fetch("https://api.paystack.co/transaction/initialize", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${PAYSTACK_SECRET_KEY.value()}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        email: customerEmail,
        amount: service.amountMinor,
        currency: service.currency,
        reference: orderRef.id,
        callback_url: "https://YOUR_DOMAIN/payment-return"
      })
    });
    const result = await response.json();
    if (!response.ok || !result.status || !result.data?.authorization_url) {
      await orderRef.update({ paymentStatus: "initialization_failed" });
      throw new HttpsError("internal", "Could not initialize payment. Please try again.");
    }
    await orderRef.update({ paymentReference: result.data.reference });
    return { orderId: orderRef.id, authorizationUrl: result.data.authorization_url };
  }
);
