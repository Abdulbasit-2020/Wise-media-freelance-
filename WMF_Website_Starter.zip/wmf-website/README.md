# WMF — Wise Media Freelance

Initial website foundation using HTML, CSS, JavaScript, Firebase Hosting, Authentication, Firestore, Storage and Cloud Functions.

## Included in this first build

- Responsive premium WMF landing page using the navy / champagne-gold identity.
- Hero carousel, service overview, Author Centre introduction, process section, portfolio placeholder and contact section.
- Firebase project configuration placeholder.
- Initial Firestore and Storage security rules.
- Cloud Function scaffold for server-side Paystack initialization.
- Firebase Hosting configuration and security headers.

## Important: not production-ready yet

This is the first coding milestone, not the complete booking/payment platform. The contact form is a visual placeholder and does not submit data. Customer authentication, order dashboard, admin dashboard, private upload workflow, Paystack verification/webhook, email receipts and policy pages still need to be implemented and tested.

Do not collect real customer data or accept real payments until these features and the security rules have been completed and tested.

## 1. Requirements

Install:
- Node.js 20 or newer
- Git
- Firebase CLI: `npm install -g firebase-tools`

Create a Firebase project at https://console.firebase.google.com and register a Web App.

## 2. Configure Firebase

1. Copy the Web App configuration from Firebase Console.
2. Replace the placeholder values in `public/assets/js/firebase.js`.
3. Enable Authentication providers you want to offer (start with Email/Password).
4. Create the Cloud Firestore database.
5. Enable Firebase Storage.
6. Review and deploy `firestore.rules` and `storage.rules`.

## 3. Run locally

From the project root:

```bash
firebase login
firebase use --add
firebase emulators:start
```

If you only want to preview the static frontend, use a local static server such as VS Code Live Server. Do not open the HTML file directly because browser module imports need a local server.

## 4. Deploy the frontend

```bash
firebase deploy --only hosting
```

Deploy rules:

```bash
firebase deploy --only firestore:rules,storage
```

## 5. Cloud Functions and Paystack

Cloud Functions deployment generally requires the Firebase Blaze billing plan. Before deploying:
1. Review the function source and test it in the Firebase Emulator Suite.
2. Set the Paystack secret securely: `firebase functions:secrets:set PAYSTACK_SECRET_KEY`
3. Replace `https://YOUR_DOMAIN/payment-return` with the final WMF return URL.
4. Complete a separate Paystack verification function/webhook with signature validation, amount/currency/reference matching, idempotency and server-side order status changes before accepting live payments.
5. Never place the Paystack secret key in frontend code or GitHub.

The current function initializes a transaction but intentionally does not mark an order as paid. Payment verification must be implemented before launch.

## 6. GitHub

Create an empty private repository for the project, then from this folder:

```bash
git init
git add .
git commit -m "Initial WMF website foundation"
git branch -M main
git remote add origin YOUR_GITHUB_REPOSITORY_URL
git push -u origin main
```

Do not commit secrets, service account keys, `.env` files or private customer data.

## 7. Next development milestones

1. Connect Firebase and verify the public service catalogue.
2. Build customer registration, login and profile.
3. Build dynamic service detail and booking forms.
4. Add private customer file uploads and order dashboard.
5. Implement Paystack verification/webhook and receipts.
6. Build admin dashboard, content management and role controls.
7. Add policies, SEO, analytics, backups and final security testing.

## Brand rules

- Navy: `#0B1020`
- Near-black: `#080808`
- Champagne gold: `#D6B46A`
- White: `#FFFFFF`
- Soft grey: `#F3F4F6`

Do not invent package prices, testimonials, portfolio results, awards or customer counts. Confirm all prices, delivery estimates, policies and payment-provider settings with WMF before launch.
